//
//  TouchThaNumberTests.swift
//  TouchThaNumberTests
//
//  Created by haru on 2025/08/30.
//

import Testing

struct TouchThaNumberTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
