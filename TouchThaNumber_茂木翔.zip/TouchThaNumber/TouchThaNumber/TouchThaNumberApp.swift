//
//  TouchThaNumberApp.swift
//  TouchThaNumber
//
//  Created by haru on 2025/08/30.
//

import SwiftUI

@main
struct TouchThaNumberApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
