//
//  ContentView.swift
//  TouchThaNumber
//
//  Created by haru on 2025/08/30.
//

import SwiftUI

struct ContentView: View {
    @State var list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    @State var tapnumber:Int = 0
    @State var message = "１から順番にタップしてね"
    @State var isplaying : Bool = false
    @State var alett = false
    // 1. グリッドの列の定義（3列にすることを指定）
    let columns: [GridItem] = [
        GridItem(.flexible()), // 1列目
        GridItem(.flexible()), // 2列目
        GridItem(.flexible())  // 3列目
    ]
    
    var body: some View{
        if isplaying{
            gameview
        }else{
            startview
        }
        
    }
    
    var gameview: some View {
        VStack {
            Spacer()
            Text(message)
                .font(.title)
                .padding(.bottom,150)
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(list, id: \.self) { number in
                    Button(String(number)) {
                        if self.tapnumber + 1 == number && number == 9 {
                            self.message = "終了！"
                            self.alett = true
                        }else if self.tapnumber + 1 == number{
                            self.tapnumber = number
                        }else {
                            self.message = "次は\(self.tapnumber + 1)だよ!"
                        }
                    }
                }
                    .font(.title) // 少し文字を大きくする
                    .padding(20)// ボタンの周りに余白を追加
                }
            .padding(.horizontal, 20)
            .background(Color.gray.opacity(0.2))
            Spacer()
            if alett{
                Button("スタートに戻る"){
                    self.isplaying = false
                    self.alett = false
                }
                .font(.title)
                .frame(maxWidth: .infinity) // 横幅いっぱいに広げる
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
    }
    var startview: some View{
        VStack{
            Spacer()
            Text("Tap The Number")
                .font(.title)
                .fontWeight(.bold)
            Spacer()
            Button("ゲームを始める"){
                Gamereset()
                self.isplaying = true
                self.tapnumber = 0
                self.message = "１から順番にタップしてね"
            }
            .font(.title)
            .frame(maxWidth: .infinity) // 横幅いっぱいに広げる
            .padding(20)
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
    }
    func Gamereset(){
        self.list.shuffle()
        
    }
}



#Preview {
    ContentView()
}
